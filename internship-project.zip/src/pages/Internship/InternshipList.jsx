import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

export default function InternshipList() {

    const [internships, setInternships] = useState([])

    const InternshipFetch = async () => {
        const response = await axios.get("http://localhost:5001/internships")
        setInternships(response.data)
    }

    const deleteItem = async (id) => {
        await axios.delete(`http://localhost:5001/internships/${id}`)
        setInternships(internships.filter((item) => item.id !== id))
    }

    useEffect(() => {
        InternshipFetch()
    }, [])

    return (
        <div>
            <table border="1" width="100%" cellPadding="10">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Department</th>
                        <th>Location</th>
                        <th>Type</th>
                        <th>Duration</th>
                        <th>Stipend</th>
                        <th>Slots</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {internships.map((item) => (
                        <tr key={item.id}>
                            <td>{item.title}</td>
                            <td>{item.department}</td>
                            <td>{item.location}</td>
                            <td>{item.type}</td>
                            <td>{item.duration}</td>
                            <td>{item.stipend}</td>
                            <td>{item.slots}</td>
                            <td style={{
                                color: item.status === "Open" ? "green" : "red"
                            }}>{item.status}</td>
                            <td>
                                <Link to={`/edit-internship/${item.id}`}>
                                <button>Edit</button></Link>
                                <button onClick={() => deleteItem(item.id)}>Delete</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>

        </div>
    )
}
