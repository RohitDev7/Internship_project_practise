import React, { useState } from 'react'
import axios from "axios"
import { useNavigate } from 'react-router-dom'

export default function CreateInternship() {
    const navigate = useNavigate();

    const [form, setForm] = useState({
        title: "",
        department: "",
        location: "",
        type: "Online",
        duration: "",
        stipend: "",
        slots: "",
        status: "Open"
    })

    const handleChange = (e) => {
        setForm({ ...form, [e.target.name]: e.target.value })
    }

    const handleSubmit = async (e) => {
        e.preventDefault()
        await axios.post("http://localhost:5001/internships", form)
        navigate("/internships")
    }

    return (
        <div className="signup-parent">
            <div className="signup-child">
                <div className="signup-card">
                    
                    <h2 className="signup-title">Create Internship</h2>

                    <form className="signup-form" onSubmit={handleSubmit}>

                        <div className="form-group">
                            <label>Title</label>
                            <input
                                type="text"
                                name="title"
                                onChange={handleChange}
                            />
                        </div>

                        <div className="form-group">
                            <label>Department</label>
                            <input
                                type="text"
                                name="department"
                                onChange={handleChange}
                            />
                        </div>

                        <div className="form-group">
                            <label>Location</label>
                            <input
                                type="text"
                                name="location"
                                onChange={handleChange}
                            />
                        </div>

                        <div className="form-group">
                            <label>Type</label>
                            <select name="type" onChange={handleChange}>
                                <option value="Online">Online</option>
                                <option value="Offline">Offline</option>
                            </select>
                        </div>

                        <div className="form-group">
                            <label>Duration</label>
                            <select name="duration" onChange={handleChange}>
                                <option value="1 Month">1 Month</option>
                                <option value="3 Months">3 Months</option>
                                <option value="6 Months">6 Months</option>
                            </select>
                        </div>

                        <div className="form-group">
                            <label>Stipend</label>
                            <input
                                type="text"
                                name="stipend"
                                onChange={handleChange}
                            />
                        </div>

                        <div className="form-group">
                            <label>Slots</label>
                            <input
                                type="number"
                                name="slots"
                                onChange={handleChange}
                            />
                        </div>

                        <button type="submit" className="signup-btn">
                            Create
                        </button>

                    </form>
                </div>
            </div>
        </div>
    )
}