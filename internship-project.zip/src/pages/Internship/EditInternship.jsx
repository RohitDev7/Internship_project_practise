import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'

export default function EditInternship() {

    const { id } = useParams();
    const navigate = useNavigate();


    const [form, setForm] = useState({
        title: "",
        department: "",
        location: "",
        type: "",
        duration: "",
        stipend: "",
        slots: "",
        status: ""
    })

 useEffect(() => {
        axios.get(`http://localhost:5001/internships/${id}`)
            .then(res => {
                setForm(res.data) 
            })
            .catch(err => {
                console.log("Error fetching internship details", err)
            })
    }, [id]);

    const updateInternship = async (e) => {
        e.preventDefault();
        try {
            await axios.put(`http://localhost:5001/internships/${id}`, form);
            navigate("/internships");
        }
        catch (error) {
            console.log("Error updating internship", error);
        }
    }


    return (
        <div className="signup-parent">
            <div className="signup-child">
                <div className="signup-card">
                    <h2 className="signup-title">Edit Internship</h2>

                    <form className="signup-form" onSubmit={updateInternship}>
                        <div className="form-group">
                            <label>Title</label>
                            <input
                                type="text"
                                name="title"
                                value={form.title}
                                onChange={e => setForm({ ...form, title: e.target.value })}
                            />
                        </div>

                        <div className="form-group">
                            <label>Department</label>
                            <input
                                type="text"
                                name="department"
                                value={form.department}
                                onChange={e => setForm({ ...form, department: e.target.value })}
                            />
                        </div>

                        <div className="form-group">
                            <label>Location</label>
                            <input
                                type="text"
                                name="location"
                                value={form.location}
                                onChange={e => setForm({ ...form, location: e.target.value })}
                            />
                        </div>

                        <div className="form-group">
                            <label>Type</label>
                            <select name="type" value={form.type}  onChange={e => setForm({ ...form, type: e.target.value })}>
                                <option value="Online">Online</option>
                                <option value="Offline">Offline</option>
                            </select>
                        </div>

                        <div className="form-group">
                            <label>Duration</label>
                            <select name="duration" value={form.duration}  onChange={e => setForm({ ...form, duration: e.target.value })}>
                                <option value="1 Month">1 Month</option>
                                <option value="3 Months">3 Months</option>
                                <option value="6 Months">6 Months</option>
                            </select>
                        </div>

                        <div className="form-group">
                            <label>Stipend</label>
                            <input
                                type="text"
                                name="stipend"
                                value={form.stipend}
                                onChange={e => setForm({ ...form, stipend: e.target.value })}
                            />
                        </div>

                        <div className="form-group">
                            <label>Slots</label>
                            <input
                                type="number"
                                name="slots"
                                 value={form.slots}
                                onChange={e => setForm({ ...form, slots: e.target.value })}
                            />
                        </div>

                        <div className="form-group">
                            <label>Status</label>
                            <select
                                name="status"
                                value={form.status}
                                onChange={e => setForm({ ...form, status: e.target.value })}
                            >
                                <option value="">Select Status</option>
                                <option value="Open">Open</option>
                                <option value="Closed">Closed</option>
                            </select>
                        </div>

                        <button type="submit" className="signup-btn">
                            Create
                        </button>
                    </form>
                </div>
            </div>
        </div>
    )
}
