import axios from 'axios';
import React, { useEffect, useState } from 'react'
import Table from 'react-bootstrap/Table';

export default function EmployeeDirectory() {

const [employess, setEmployess] = useState([]);

useEffect(() =>{
    axios.get("http://localhost:5001/employees")
    .then(res => setEmployess(res.data))
    .catch(err => {
        console.log("Error fetching employees", err)
    })
})

  return (
    <div>
         <Table striped bordered hover>
      <thead>
           <tr>
          <th>Name</th>
          <th>Email</th>
          <th>Department</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        {employess.map((item) =>{
            <tr key={item.id}>
                <td>{item.name}</td>
                <td>{item.email}</td>
                <td>{item.department}</td>
                <td>{item.status}</td>
            </tr>
        })}
      </tbody>
    </Table>
    </div>
  )
}
